#zad2
#x^7+2x^5+x^4+4x+1


x_0 = 0;
max_iter = 1000;
epsilon = 10^-3; # dokladnosc rozwiazania
delta = 10^-2; # maksymalna odleglosc rozwiazania

f = @(x) log(x + 100) + sin(x) + x; # wzor funckji
df = @(x) 1 + 1/(100 + x) + cos(x); # pochodna

for i=1: max_iter
    x = x_0 - f(x_0)/df(x_0);

    if abs(x - x_0) < delta && abs(f(x)) < epsilon
        display('Rozwiazanie:')
        display(x);
        break;
    endif

    x_0 = x;
endfor

K = [1, 4, 0, 0, 1, 2,0,1];


result = SchematHornera(K, x_0)







































x
6
