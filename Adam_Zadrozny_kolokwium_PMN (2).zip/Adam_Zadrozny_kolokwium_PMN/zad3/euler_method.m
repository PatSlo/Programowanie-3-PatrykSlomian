function euler_method()
    n_values = [10, 20, 50, 100];

    exact_solution = exp(2);

    for n = n_values
        dx = 1 / n;
        x = 0:dx:1;
        y = zeros(1, n+1);
        y(1) = 1;

        for i = 1:n
            y(i+1) = y(i) + dx * 2 * y(i);
        end

        relative_error = abs((y(end) - exact_solution) / exact_solution);


        fprintf('n = %d: Przybli�enie = %f, B��d wzgl�dny = %f\n', n, y(end), relative_error);
    end
end


euler_method();
