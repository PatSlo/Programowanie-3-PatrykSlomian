# SchematHornera

function y = SchematHornera(K, x)
  # K - lista współczynników wielomiany (od tylu)
  # x - punkt dla którego liczymy wartosc

  n = length(K);
  y = K(n);

  for (i = (n - 1): -1: 1)
    y = y * x + K(i);
  endfor
endfunction
