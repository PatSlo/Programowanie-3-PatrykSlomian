function result = SzeregNeumanna(B, i)
  # B - Macierz
  # i - liczba pierwszych składników (np i=4 - liczba pierwszych czterech skladnikow)
  I = eye(size(B));
  A = I - B;

  norm_A = norm(A, inf); # Obliczanie normy macierzy A

  # Sprawdzenie warunku - czy założenia twierdzenia o szeregu Neumanna są spełnione
  if norm_A < 1
    # Obliczanie sumy pierwszych składników szeregu Neumanna
    B_inv_app = I;
    A_pow = A;

    for n = 1 : i-1
      B_inv_app = B_inv_app + A_pow;
      A_pow = A_pow * A;
    end

    result = B_inv_app;
    display("Założenie twierdzenia o szeregu Neumanna jest spełnione!");

  else
    display("Założenie twierdzenia o szeregu Neumanna jest niespełnione!");
    result = NaN
  endif
endfunction
