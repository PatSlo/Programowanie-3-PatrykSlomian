function retval = EliminacjaGaussa(A, b)
  n=columns(A);

  for(i=1:(n-1))
    A(i,:);
    for(j=(i+1):n)
      z=A(j,i)/A(i,i);
      A(j,i)=0;
      for(k=(i+1):n)
        A(j,k)=A(j,k)-z*A(i,k);
      endfor
      b(j)=b(j)-z*b(i);
    endfor
  endfor
  retval=RedukcjaWsteczna(A,b);

endfunction

function x = RedukcjaWsteczna(A, b)
  n = length(b); % n - dł. wektora b
  x = zeros(n, 1); % wektor 9x1 z samymi zerami

  for i = n : -1 : 1 % pętla przechodząca przez indeksy n w odwrotnej kolejności
    sum = A(i, (i + 1) : n) * x((i + 1) : n); % obliczanie sumy iloczynów elementów w i-tym wierszy macierzy A i odpowiadających im elementów wektora x
    x(i) = (b(i) - sum) / A(i, i); % obliczanie i-tego elementu wektora x poprzez odjęcie wcześniej obliczonej sumy i podzielenie przez element na przekątnej macierzy A
  endfor
endfunction
