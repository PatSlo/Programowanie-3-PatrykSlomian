
# Zadanie 1.
B = [1, 0.2; 0.2, 0.75]; # Definicja macierzy
result = SzeregNeumanna(B, 8)


max_iter = 1000;

# metoda potegowa
n = size(A, 1);
v_1 = randn(n, 1);

for i=1: max_iter
  w = A * v_1;
  v_1 = w / norm(w);
  lambda_1 = v_1' * A * v_1;
endfor

display("Metoda potegowa");
v_1 # wektor wlasny
lambda_1 # wartosc wlasna

# odwrotna metoda potegowa
n = size(A, 1);
v_2 = randn(n, 1);

for i=1: max_iter
  w = A \ v_2;
  v_2 = w / norm(w);
  lambda_2 = v_2' * A * v_2;
endfor

lambda_2 = 1 / lambda_2;

display("Odwrotna metoda potegowa");
v_2 # wektor wlasny
lambda_2 # wartosc wlasna

display("Promien spektralny")
spect_radius = max(abs([lambda_1, lambda_2]))

